import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'header' | 'default' | 'monochrome' | 'badge';
  showSlogan?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const OFFICIAL_LOGO_SRC = "/assets/aistudio/fe030479-dcea-4fa5-9a08-92d8802d7005_4530a491.jpeg";

export const Logo: React.FC<LogoProps> = ({
  className = '',
  variant = 'header',
  showSlogan = true,
  size = 'md',
}) => {
  const isHeader = variant === 'header';

  // Sizing for the circular logo emblem
  const sizeClasses = {
    sm: 'w-10 h-10',
    md: 'w-12 h-12 sm:w-14 sm:h-14',
    lg: 'w-20 h-20 sm:w-24 sm:h-24',
  }[size];

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Official Brand Emblem: Real uploaded client logo */}
      <div className={`relative shrink-0 ${sizeClasses} rounded-full overflow-hidden shadow-md border-2 border-white/90 bg-white flex items-center justify-center transition-transform duration-200 hover:scale-105`}>
        <img
          src={OFFICIAL_LOGO_SRC}
          alt="Luzia Corrêa Turismo - Logo Oficial"
          className="w-full h-full object-cover object-center"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Brand Typography: Nome da empresa em letras vermelhas com fonte slim itálico */}
      <div className="flex flex-col justify-center leading-tight">
        <span
          className="font-['Outfit',sans-serif] italic tracking-tight text-[28px] sm:text-[36px] font-normal text-[#D32F2F] drop-shadow-[0_1.5px_1px_rgba(255,255,255,0.85)] leading-none"
        >
          Luzia Corrêa
        </span>
        <div className="flex items-center gap-1.5 mt-0.5">
          <span
            className={`font-montserrat tracking-[0.22em] text-[12px] sm:text-[14px] font-bold uppercase ${
              isHeader ? 'text-neutral-950' : 'text-[#064E3B]'
            }`}
          >
            Turismo
          </span>
          {showSlogan && (
            <>
              <span className={`text-[9px] ${isHeader ? 'text-neutral-800' : 'text-slate-400'}`}>•</span>
              <span
                className={`font-montserrat text-[10px] italic font-bold hidden xs:inline ${
                  isHeader ? 'text-neutral-900' : 'text-amber-600'
                }`}
              >
                Viaje mais. Viva mais!
              </span>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
