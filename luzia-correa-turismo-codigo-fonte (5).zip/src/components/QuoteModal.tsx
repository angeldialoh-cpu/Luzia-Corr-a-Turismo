import React, { useState, useEffect } from 'react';
import { X, MessageCircle, Send, Calendar, Users, MapPin, User, Phone, CheckCircle2 } from 'lucide-react';
import { BRAND, buildWhatsAppUrl } from '../config/constants.ts';
import { DESTINATIONS_DATA } from './DestinationsSection.tsx';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  presetDestination?: string;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({
  isOpen,
  onClose,
  presetDestination = '',
}) => {
  const [name, setName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [excursion, setExcursion] = useState(presetDestination);
  const [date, setDate] = useState('');
  const [peopleCount, setPeopleCount] = useState('2');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    if (presetDestination) {
      setExcursion(presetDestination);
    }
  }, [presetDestination]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const validate = () => {
    const err: Record<string, string> = {};
    if (!name.trim()) err.name = 'Por favor, informe seu nome completo.';
    if (!whatsapp.trim() || whatsapp.trim().length < 8) {
      err.whatsapp = 'Informe um número de WhatsApp válido com DDD.';
    }
    if (!excursion.trim()) {
      err.excursion = 'Selecione ou digite a excursão desejada.';
    }
    if (!peopleCount || parseInt(peopleCount) < 1) {
      err.peopleCount = 'Informe pelo menos 1 pessoa.';
    }
    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    // Build the formatted WhatsApp message exactly as requested
    const formattedMessage = `Olá! Gostaria de solicitar informações sobre uma excursão da Luzia Corrêa Turismo.

Nome: ${name.trim()}
Excursão: ${excursion.trim()}
Data: ${date.trim() ? date.trim() : 'A combinar'}
Quantidade de pessoas: ${peopleCount}
Observações: ${notes.trim() ? notes.trim() : 'Nenhuma observação'}`;

    setIsSuccess(true);

    const waUrl = buildWhatsAppUrl(formattedMessage);
    
    // Open WhatsApp
    setTimeout(() => {
      window.open(waUrl, '_blank');
      // Reset form and close
      setName('');
      setWhatsapp('');
      setExcursion('');
      setDate('');
      setPeopleCount('2');
      setNotes('');
      setIsSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-cyan-100 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-[#FACC15] px-6 py-4.5 border-b border-amber-400 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-neutral-900 block">
              Luzia Corrêa Turismo
            </span>
            <h3 className="font-playfair text-xl font-bold text-neutral-950">
              Solicitar Orçamento / Reserva
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full bg-amber-400/80 text-neutral-950 hover:bg-neutral-950 hover:text-white transition-colors"
            aria-label="Fechar formulário"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto">
          {isSuccess ? (
            <div className="py-10 text-center flex flex-col items-center">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-4 animate-bounce">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="font-playfair text-2xl font-bold text-slate-900 mb-2">
                Preparando seu atendimento!
              </h4>
              <p className="font-montserrat text-sm text-slate-600 max-w-xs mb-4">
                Estamos transferindo seus dados formatados diretamente para o WhatsApp da Luzia Corrêa Turismo...
              </p>
              <div className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-4 py-2 rounded-lg">
                Redirecionando para o WhatsApp...
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <p className="text-xs text-slate-600 font-medium">
                Preencha os campos abaixo para que nossa equipe monte sua proposta personalizada e envie as informações completas no WhatsApp.
              </p>

              {/* Nome */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Seu Nome *
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Maria Helena da Silva"
                    className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 transition-all ${
                      errors.name
                        ? 'border-red-400 focus:ring-red-400'
                        : 'border-slate-200 focus:border-amber-400 focus:ring-amber-400/30'
                    }`}
                  />
                </div>
                {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name}</p>}
              </div>

              {/* WhatsApp */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Seu WhatsApp (com DDD) *
                </label>
                <div className="relative">
                  <Phone className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="tel"
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    placeholder="Ex: (21) 99876-5432"
                    className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 transition-all ${
                      errors.whatsapp
                        ? 'border-red-400 focus:ring-red-400'
                        : 'border-slate-200 focus:border-amber-400 focus:ring-amber-400/30'
                    }`}
                  />
                </div>
                {errors.whatsapp && <p className="text-xs text-red-500 mt-1">{errors.whatsapp}</p>}
              </div>

              {/* Excursão ou Destino */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Excursão ou Destino Desejado *
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    list="destinations-list"
                    value={excursion}
                    onChange={(e) => setExcursion(e.target.value)}
                    placeholder="Ex: Cristo Redentor, Arraial do Cabo, Pão de Açúcar..."
                    className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 transition-all ${
                      errors.excursion
                        ? 'border-red-400 focus:ring-red-400'
                        : 'border-slate-200 focus:border-amber-400 focus:ring-amber-400/30'
                    }`}
                  />
                  <datalist id="destinations-list">
                    {DESTINATIONS_DATA.map((d) => (
                      <option key={d.id} value={d.name} />
                    ))}
                    <option value="Excursões pelo Rio de Janeiro" />
                    <option value="Passeios Turísticos" />
                    <option value="Experiências em Grupo" />
                    <option value="Viagens Especiais de Temporada" />
                  </datalist>
                </div>
                {errors.excursion && <p className="text-xs text-red-500 mt-1">{errors.excursion}</p>}
              </div>

              {/* Grid: Data + Quantidade de pessoas */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Data Desejada */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Data Desejada
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      placeholder="Ex: Próximo sábado / Outubro"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/30"
                    />
                  </div>
                </div>

                {/* Quantidade de Pessoas */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Quantidade de Pessoas *
                  </label>
                  <div className="relative">
                    <Users className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                    <input
                      type="number"
                      min="1"
                      max="50"
                      value={peopleCount}
                      onChange={(e) => setPeopleCount(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/30"
                    />
                  </div>
                </div>
              </div>

              {/* Observações */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Observações (Opcional)
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ex: Viajando com idoso ou criança, ponto de encontro preferido..."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/30 resize-none"
                />
              </div>

              {/* Submit CTA button */}
              <button
                type="submit"
                className="w-full mt-2 inline-flex items-center justify-center gap-2.5 py-3.5 px-6 rounded-xl font-extrabold text-sm text-neutral-950 bg-amber-400 hover:bg-amber-300 active:scale-98 shadow-md transition-all cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 fill-neutral-950" />
                <span>Enviar Solicitação para o WhatsApp</span>
              </button>

              <p className="text-[11px] text-center text-slate-500">
                Seus dados são protegidos e enviados diretamente para nosso atendimento no WhatsApp.
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
