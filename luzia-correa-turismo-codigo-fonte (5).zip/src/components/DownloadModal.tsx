import React, { useState } from 'react';
import { Download, FolderArchive, X, Check, ExternalLink, HelpCircle } from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose }) => {
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (url: string, label: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(label);
    setTimeout(() => setCopiedLink(null), 3000);
  };

  const origin = window.location.origin;
  const netlifyUrl = `${origin}/luzia-correa-turismo-site-pronto.zip`;
  const lovableUrl = `${origin}/luzia-correa-turismo-codigo-fonte.zip`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative max-w-lg w-full bg-white rounded-3xl overflow-hidden shadow-2xl p-6 sm:p-8 border border-slate-100 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-900 hover:bg-slate-100 transition-colors"
          aria-label="Fechar"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-2xl bg-amber-400/20 text-amber-600 flex items-center justify-center shrink-0">
            <Download className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-playfair text-xl sm:text-2xl font-bold text-slate-900">
              Baixar Projeto (.ZIP)
            </h3>
            <p className="text-xs text-slate-500">
              Escolha o formato ideal para onde você deseja hospedar
            </p>
          </div>
        </div>

        {/* Options */}
        <div className="space-y-4 my-6">
          {/* Option 1: Netlify */}
          <div className="p-4 rounded-2xl bg-amber-50/70 border-2 border-amber-300 flex flex-col gap-3">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-400 text-neutral-950 text-[10px] font-black uppercase tracking-wider mb-1">
                  Recomendado para Netlify
                </span>
                <h4 className="font-bold text-slate-900 text-sm">
                  1. Site Pronto para Publicar (Build de Produção)
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed mt-0.5">
                  Contém o HTML, CSS e imagens prontos para arrastar e soltar no <strong>app.netlify.com/drop</strong>.
                </p>
              </div>
            </div>
            <a
              href="/luzia-correa-turismo-site-pronto.zip"
              download="luzia-correa-turismo-site-pronto.zip"
              className="inline-flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-extrabold text-xs shadow-md transition-all active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>Baixar ZIP para Netlify (5.7 MB)</span>
            </a>
          </div>

          {/* Option 2: Lovable & GitHub */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col gap-3">
            <div>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-200 text-slate-800 text-[10px] font-black uppercase tracking-wider mb-1">
                Para Lovable & GitHub
              </span>
              <h4 className="font-bold text-slate-900 text-sm">
                2. Código-Fonte Completo (React + Vite + Tailwind)
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed mt-0.5">
                Contém todos os arquivos editáveis (.tsx, .ts, configs, componentes) para abrir no Lovable ou VS Code.
              </p>
            </div>
            <a
              href="/luzia-correa-turismo-codigo-fonte.zip"
              download="luzia-correa-turismo-codigo-fonte.zip"
              className="inline-flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs shadow-md transition-all active:scale-95"
            >
              <FolderArchive className="w-4 h-4 text-cyan-400" />
              <span>Baixar Código-Fonte ZIP (6.5 MB)</span>
            </a>
          </div>
        </div>

        {/* Quick Instructions */}
        <div className="text-[11px] text-slate-500 bg-slate-100 p-3.5 rounded-xl space-y-1.5">
          <div className="font-bold text-slate-700 flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
            <span>Como hospedar em 3 passos no Netlify:</span>
          </div>
          <ol className="list-decimal list-inside space-y-0.5 text-slate-600">
            <li>Baixe o arquivo 1 acima e descompacte a pasta no computador.</li>
            <li>Abra o site <strong>app.netlify.com/drop</strong>.</li>
            <li>Arraste a pasta descompactada para a tela. Seu site já estará online!</li>
          </ol>
        </div>
      </div>
    </div>
  );
};
