import React, { useState } from 'react';
import { Eye, MessageCircle, MapPin, Calendar, Clock, Sparkles, ZoomIn, X, PhoneCall } from 'lucide-react';
import { buildWhatsAppUrl } from '../config/constants.ts';

// Imported generated Rio photography assets
import cristoImg from '../assets/images/dest_cristo_corcovado_1793313955510.jpg';
import paoDeAcucarImg from '../assets/images/dest_pao_de_acucar_1793313957328.jpg';
import arraialImg from '../assets/images/dest_arraial_do_cabo_1793313956369.jpg';
import petropolisImg from '../assets/images/dest_regiao_serrana_1793313957413.jpg';
import heroRioImg from '../assets/images/hero_rio_de_janeiro_1793313955112.jpg';
// User-provided official destination images
const penedoImg = "/assets/aistudio/penedo-rj-dicas_c84a2b02.jpg";
const aparecidaImg = "/assets/aistudio/Vida-sem-Paredes-Aparecida-19_867b8184.webp";
const feiraNordestinaImg = "/assets/aistudio/6223_feira-de-sao-cristovao_divulgacao_6d195a2f.webp";
const proximosPasseiosFlyerSrc = "/assets/aistudio/dad0c58a-3df9-421e-a1da-3a4a32366619_f43871df.jpeg";

export interface Destination {
  id: string;
  name: string;
  category: 'rio' | 'praias' | 'cultura' | 'natureza' | 'especiais';
  categoryLabel: string;
  image: string;
  description: string;
  duration: string;
  highlightBadge?: string;
  inclusions: string[];
  itinerary: string[];
  recommendation: string;
}

export const DESTINATIONS_DATA: Destination[] = [
  {
    id: 'penedo-pequena-finlandia',
    name: 'Penedo & Pequena Finlândia',
    category: 'cultura',
    categoryLabel: 'Penedo / Serra',
    image: penedoImg,
    description: 'A charmosa colônia finlandesa no Rio de Janeiro, com a famosa rua dos guarda-chuvas coloridos, lojas de artesanato e chocolates artesanais.',
    duration: 'Excursão de 1 dia (Bate e Volta)',
    highlightBadge: 'Rua dos Guarda-Chuvas',
    inclusions: [
      'Transporte executivo com ar-condicionado e serviço de bordo',
      'Passeio livre pelo charmoso centro e Pequena Finlândia',
      'Paradas fotográficas na famosa Rua dos Guarda-Chuvas',
      'Tempo livre para compras de chocolates e artesanato local',
    ],
    itinerary: [
      'Embarque organizado nos pontos combinados',
      'Subida da serra fluminense em direção a Penedo (Itatiaia/RJ)',
      'Chegada e caminhada pela Pequena Finlândia e Casa de Papai Noel',
      'Tempo livre para almoço típico e parada nas chocolaterias',
      'Retorno confortável com o grupo no final da tarde',
    ],
    recommendation: 'Traga a câmera ou celular carregado para fotos na rua dos guarda-chuvas e prepare-se para saborear ótimos chocolates!',
  },
  {
    id: 'cristo-corcovado',
    name: 'Cristo Redentor & Mirante do Corcovado',
    category: 'rio',
    categoryLabel: 'Rio de Janeiro',
    image: cristoImg,
    description: 'Subida confortável com van oficial pelas curvas da Floresta da Tijuca até os pés da Maravilha do Mundo Moderno.',
    duration: 'Dia completo ou Meio período',
    highlightBadge: 'Cartão-Postal Obrigatório',
    inclusions: [
      'Transporte executivo ida e volta com ar-condicionado',
      'Ingresso oficial com acesso prioritário ao monumento',
      'Guia credenciado CADASTUR acompanhando todo o grupo',
      'Tempo livre para fotos panorâmicas da Baía de Guanabara',
    ],
    itinerary: [
      'Ponto de encontro e embarque nos pontos autorizados',
      'Subida panorâmica pela Floresta da Tijuca',
      'Chegada ao topo do Corcovado e contemplação do Cristo Redentor',
      'Parada para fotos nos mirantes da Baía de Guanabara e Lagoa',
      'Retorno confortável aos pontos de origem',
    ],
    recommendation: 'Use calçados confortáveis, leve protetor solar, óculos escuros e documento de identidade com foto.',
  },
  {
    id: 'pao-de-acucar-urca',
    name: 'Pão de Açúcar & Bondinho da Urca',
    category: 'rio',
    categoryLabel: 'Rio de Janeiro',
    image: paoDeAcucarImg,
    description: 'A clássica travessia aérea de bondinho com a vista de 360° mais deslumbrante de praias, montanhas e enseadas do Rio.',
    duration: 'Meio período ou Pôr do Sol',
    highlightBadge: 'Vista Mais Famosa do Mundo',
    inclusions: [
      'Transporte executivo com assistência permanente',
      'Ingressos dos dois trechos do Bondinho (Morro da Urca + Pão de Açúcar)',
      'Acompanhamento de guia durante toda a vivência',
      'Parada opcional na charmosa mureta da Urca',
    ],
    itinerary: [
      'Embarque organizado e translado até o bairro da Urca',
      'Primeiro trecho do teleférico até a Praça dos Bondinhos Históricos',
      'Segundo trecho até o cume do Pão de Açúcar (396m de altitude)',
      'Tempo para relaxar nos mirantes, café panorâmico e fotos',
      'Retorno tranquilo com o grupo',
    ],
    recommendation: 'Excelente para todas as idades, com estrutura plana e acessível. Uma câmera ou celular bem carregado é essencial!',
  },
  {
    id: 'arraial-do-cabo',
    name: 'Arraial do Cabo: O Caribe Brasileiro',
    category: 'praias',
    categoryLabel: 'Praias',
    image: arraialImg,
    description: 'Excursão de um dia inteiro pelas águas azul-turquesa mais translúcidas do Brasil com passeio de escuna animado.',
    duration: 'Excursão de 1 dia (Bate e Volta)',
    highlightBadge: 'Águas Mais Cristalinas',
    inclusions: [
      'Ônibus ou micro-ônibus executivo com serviço de bordo',
      'Passeio de escuna/barco com paradas para banho e mergulho',
      'Parada nas Prainhas do Pontal do Atalaia e Ilha do Farol',
      'Almoço buffet em restaurante parceiro selecionado',
    ],
    itinerary: [
      'Embarque matutino nos pontos combinados',
      'Chegada a Arraial do Cabo e embarque imediato na escuna',
      'Navegação com paradas nos pontos mais paradisíacos',
      'Almoço delicioso após o passeio de barco',
      'Tempo para compras de lembrancinhas e retorno no fim da tarde',
    ],
    recommendation: 'Leve roupa de banho, toalha, muda de roupa seca, protetor solar biodegradável e muita disposição para curtir o mar.',
  },
  {
    id: 'petropolis-imperial',
    name: 'Petrópolis Imperial & Palácios da Serra',
    category: 'cultura',
    categoryLabel: 'Cultura & História',
    image: petropolisImg,
    description: 'Viagem de charme ao clima serrano com visita ao Museu Imperial, Palácio Quitandinha e a Casa de Santos Dumont.',
    duration: 'Dia completo (Serra Fluminense)',
    highlightBadge: 'Clima Serrano Acolhedor',
    inclusions: [
      'Transporte executivo especial para a serra com guia local',
      'Visita guiada ao Museu Imperial com sapatilhas históricas',
      'Parada para fotos na Catedral São Pedro de Alcântara e Quitandinha',
      'Tempo livre na famosa Rua Teresa para compras e chocolates',
    ],
    itinerary: [
      'Subida da exuberante Serra dos Órgãos com parada panorâmica',
      'Visita ao Palácio e Jardins do Museu Imperial',
      'Pausa para almoço típico da culinária serrana',
      'Tour histórico pelo Centro e Casa Encantada de Santos Dumont',
      'Parada para chocolates artesanais e retorno com o grupo',
    ],
    recommendation: 'Leve um agasalho leve mesmo no verão, pois a temperatura na serra costuma ser mais amena.',
  },
  {
    id: 'feira-dos-nordestinos',
    name: 'Feira dos Nordestinos (São Cristóvão)',
    category: 'cultura',
    categoryLabel: 'Cultura & Gastronomia',
    image: feiraNordestinaImg,
    description: 'Um pedaço do Nordeste no Rio: culinária típica com baião de dois, forró ao vivo, repente, artesanato e muita alegria.',
    duration: 'Passeio Cultural e Gastronômico',
    highlightBadge: 'Comida Típica & Forró',
    inclusions: [
      'Transporte executivo com todo o conforto, segurança e ar-condicionado',
      'Ingresso de acesso ao Centro Luiz Gonzaga de Tradições Nordestinas',
      'Tempo livre para almoço típico nos tradicionais restaurantes',
      'Música ao vivo, palcos de forró, lojas de artesanato e doces regionais',
    ],
    itinerary: [
      'Embarque nos pontos oficiais da excursão com serviço de bordo',
      'Chegada com o grupo ao Pavilhão de São Cristóvão',
      'Passeio monitorado pelas alamedas temáticas e estátuas de cordel',
      'Tempo livre para almoçar, dançar forró e comprar lembrancinhas',
      'Retorno alegre e seguro com o grupo no final da tarde',
    ],
    recommendation: 'Venha com apetite para provar os pratos nordestinos e muita energia para dançar e curtir com o grupo!',
  },
  {
    id: 'aparecida-do-norte',
    name: 'Aparecida do Norte & Santuário Nacional',
    category: 'especiais',
    categoryLabel: 'Turismo Religioso',
    image: aparecidaImg,
    description: 'Romaria e excursão de fé ao Santuário Nacional de Nossa Senhora Aparecida, com a Passarela da Fé, Basílica e Sala das Promessas.',
    duration: 'Bate e Volta ou Fim de Semana',
    highlightBadge: 'Passarela da Fé & Basílica',
    inclusions: [
      'Ônibus executivo luxo com ar-condicionado e serviço de bordo',
      'Acompanhamento de guia e suporte dedicado durante toda a romaria',
      'Tempo livre para missas, orações e visita à Imagem Milagrosa',
      'Passeio pela Passarela da Fé, Basílica Velha e compras de artigos religiosos',
    ],
    itinerary: [
      'Embarque noturno ou matutino com serviço de acolhimento',
      'Chegada ao Santuário Nacional de Aparecida',
      'Participação na Santa Missa e visita à Imagem de Nossa Senhora',
      'Travessia pela Passarela da Fé e visitação à Basílica Histórica',
      'Almoço e tempo livre no Centro de Apoio aos Romeiros',
      'Retorno tranquilo e abençoado para os pontos de origem',
    ],
    recommendation: 'Use calçados confortáveis para a caminhada na passarela, leve garrafinha de água e muita devoção no coração.',
  },
];

interface DestinationsSectionProps {
  onOpenDetails: (destination: Destination) => void;
  onOpenQuoteModal: (destinationName?: string) => void;
}

export const DestinationsSection: React.FC<DestinationsSectionProps> = ({
  onOpenDetails,
  onOpenQuoteModal,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'rio' | 'praias' | 'cultura' | 'especiais'>('all');
  const [isFlyerZoomOpen, setIsFlyerZoomOpen] = useState(false);

  const filteredDestinations = activeTab === 'all'
    ? DESTINATIONS_DATA
    : DESTINATIONS_DATA.filter((d) => d.category === activeTab);

  const filterTabs = [
    { key: 'all', label: 'Todos os Destinos' },
    { key: 'rio', label: 'Rio de Janeiro' },
    { key: 'praias', label: 'Praias & Ilhas' },
    { key: 'cultura', label: 'Cultura & História' },
    { key: 'especiais', label: 'Religioso & Especiais' },
  ] as const;

  return (
    <section id="destinos" className="py-16 sm:py-24 bg-[#00B4D8] relative border-t border-cyan-300/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 text-[#0E7490] font-montserrat text-xs font-extrabold tracking-wider uppercase mb-3 shadow-sm">
            <span>Roteiros Selecionados</span>
          </div>

          <h2 className="font-playfair text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight mb-3 drop-shadow">
            Conheça nossos destinos
          </h2>

          <p className="font-montserrat text-base sm:text-lg text-white/95 font-medium leading-relaxed drop-shadow-sm">
            Lugares incríveis para viver novas experiências com a Luzia Corrêa Turismo.
          </p>
        </div>

        {/* Filter Tabs (Interactive Filter Controls, anti-slop compliant) */}
        <div className="flex items-center justify-center mb-10 sm:mb-12 overflow-x-auto pb-2 scrollbar-none">
          <div className="inline-flex p-1.5 bg-white/95 backdrop-blur-md rounded-2xl border border-white/60 shadow-md gap-1">
            {filterTabs.map((tab) => {
              const isActive = activeTab === tab.key;
              return (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => setActiveTab(tab.key)}
                  className={`px-3.5 sm:px-5 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all duration-150 cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-neutral-950 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Visual Destination Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredDestinations.map((dest) => {
            const reservationMsg = `Olá! Gostaria de reservar vaga na excursão para ${dest.name} com a Luzia Corrêa Turismo.`;
            return (
              <div
                key={dest.id}
                className="group bg-white rounded-3xl overflow-hidden border border-cyan-100 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  {/* Image container */}
                  <div className="relative h-56 sm:h-64 w-full overflow-hidden bg-slate-100">
                    <img
                      src={dest.image}
                      alt={dest.name}
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/75 via-transparent to-transparent" />

                    {/* Top Tag */}
                    <div className="absolute top-3.5 left-3.5">
                      <span className="inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-extrabold uppercase tracking-wider bg-amber-400 text-neutral-950 shadow-sm">
                        {dest.categoryLabel}
                      </span>
                    </div>

                    {/* Duration chip */}
                    <div className="absolute bottom-3.5 left-3.5 flex items-center gap-1.5 text-white text-xs font-medium">
                      <Clock className="w-3.5 h-3.5 text-amber-300" />
                      <span>{dest.duration}</span>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 sm:p-6">
                    <h3 className="font-playfair text-xl sm:text-2xl font-bold text-slate-900 mb-2 leading-snug group-hover:text-cyan-800 transition-colors">
                      {dest.name}
                    </h3>

                    <p className="font-montserrat text-xs sm:text-sm text-slate-600 leading-relaxed mb-4">
                      {dest.description}
                    </p>

                    {/* Inclusions summary (2 items) */}
                    <div className="pt-3 border-t border-slate-100 space-y-1 mb-2">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                        Incluso no passeio:
                      </div>
                      <p className="text-xs text-slate-600 line-clamp-2">
                        ✓ {dest.inclusions[0]}
                      </p>
                      <p className="text-xs text-slate-600 line-clamp-1">
                        ✓ {dest.inclusions[1]}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Card Actions: Ver detalhes & Quero reservar */}
                <div className="p-5 sm:p-6 pt-0 flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => onOpenDetails(dest)}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer text-center"
                  >
                    <Eye className="w-4 h-4 text-slate-600" />
                    <span>Ver detalhes</span>
                  </button>

                  <a
                    href={buildWhatsAppUrl(reservationMsg)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 transition-all cursor-pointer shadow-sm text-center"
                  >
                    <MessageCircle className="w-4 h-4 fill-white" />
                    <span>Quero reservar</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Official "Próximos Passeios" Flyer Showcase Card (fundo amarelo suavizando para o vermelho) */}
        <div className="mt-14 rounded-3xl bg-gradient-to-br from-[#FACC15] via-[#FB923C] to-[#DC2626] border-2 border-amber-300/80 shadow-2xl overflow-hidden p-6 sm:p-8 lg:p-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left: Official Flyer Image with zoom button */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <div
                onClick={() => setIsFlyerZoomOpen(true)}
                className="group relative rounded-2xl overflow-hidden shadow-xl border-4 border-white bg-white cursor-pointer max-w-sm w-full transition-transform hover:scale-[1.02]"
                title="Clique para ampliar o cartaz oficial dos Próximos Passeios"
              >
                <img
                  src={proximosPasseiosFlyerSrc}
                  alt="Cartaz oficial dos Próximos Passeios da Luzia Corrêa Turismo"
                  className="w-full h-auto object-contain"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-neutral-950/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white text-neutral-950 font-bold text-xs shadow-md">
                    <ZoomIn className="w-3.5 h-3.5 text-amber-500" />
                    <span>Clique para ampliar</span>
                  </span>
                </div>
              </div>
              <span className="text-xs text-neutral-950 font-semibold mt-2 drop-shadow-sm bg-white/70 px-3 py-0.5 rounded-full">
                Clique no cartaz para ver em tela cheia
              </span>
            </div>

            {/* Right: Summary of upcoming excursion dates & direct reservation */}
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 text-red-700 font-montserrat text-xs font-extrabold tracking-wider uppercase mb-3 border border-white/80 shadow-sm">
                <Calendar className="w-3.5 h-3.5 text-red-600" />
                <span>Calendário Oficial de Saídas</span>
              </div>

              <h3 className="font-playfair text-2xl sm:text-3xl font-extrabold text-neutral-950 mb-3 drop-shadow-sm">
                Garanta sua vaga nos Próximos Passeios!
              </h3>

              <p className="font-montserrat text-sm text-neutral-900 font-medium leading-relaxed mb-6">
                Confira as datas confirmadas para as nossas próximas excursões e reserve com antecedência diretamente com a equipe da Luzia Corrêa Turismo:
              </p>

              {/* Grid of trips from the flyer */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                {[
                  { name: 'Feira da Glória', date: '01 Novembro' },
                  { name: 'Aparecida do Norte', date: '06 Novembro' },
                  { name: 'Sítio dos Netinhos', date: '15 Novembro' },
                  { name: 'Friburgo com Circuito Amparo', date: '19/20 Novembro' },
                  { name: 'Hotel Fazenda das Colinas', date: '24 Janeiro' },
                  { name: 'Aldeia das Águas (Parque Aquático)', date: '21 Fevereiro' },
                ].map((item) => (
                  <div
                    key={item.name}
                    className="p-3 rounded-xl bg-white/95 backdrop-blur-sm border border-white/80 shadow-sm hover:shadow-md transition-shadow flex items-center justify-between gap-2"
                  >
                    <div>
                      <span className="font-bold text-slate-900 text-xs sm:text-sm block">
                        {item.name}
                      </span>
                      <span className="text-[11px] text-[#0E7490] font-semibold">
                        Data confirmada
                      </span>
                    </div>
                    <span className="text-xs font-extrabold text-red-600 bg-red-50 border border-red-200 px-2.5 py-1 rounded-md shrink-0">
                      {item.date}
                    </span>
                  </div>
                ))}
              </div>

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <a
                  href={buildWhatsAppUrl("Olá! Gostaria de reservar vaga em um dos Próximos Passeios da Luzia Corrêa Turismo.")}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl text-sm font-extrabold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 transition-all shadow-lg text-center"
                >
                  <MessageCircle className="w-5 h-5 fill-white" />
                  <span>Reservar pelo WhatsApp: (21) 98539-6446</span>
                </a>

                <button
                  type="button"
                  onClick={() => onOpenQuoteModal()}
                  className="inline-flex items-center justify-center px-5 py-3.5 rounded-xl text-sm font-extrabold text-white bg-neutral-950 hover:bg-neutral-800 transition-colors shadow-md text-center"
                >
                  Personalizar para seu grupo
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Lightbox / Zoom Modal for the full Próximos Passeios flyer */}
        {isFlyerZoomOpen && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/85 backdrop-blur-sm animate-in fade-in duration-200"
            onClick={() => setIsFlyerZoomOpen(false)}
          >
            <div
              className="relative max-w-2xl w-full max-h-[90vh] bg-white rounded-3xl overflow-hidden shadow-2xl p-2 flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={() => setIsFlyerZoomOpen(false)}
                className="absolute top-4 right-4 z-10 p-2 rounded-full bg-neutral-900/80 text-white hover:bg-neutral-950 transition-colors"
                aria-label="Fechar"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="overflow-y-auto max-h-[85vh] rounded-2xl">
                <img
                  src={proximosPasseiosFlyerSrc}
                  alt="Luzia Corrêa Turismo - Próximos Passeios Oficial"
                  className="w-full h-auto object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
