import React, { useEffect } from 'react';
import { X, CheckCircle2, Calendar, MapPin, Clock, MessageCircle, AlertCircle } from 'lucide-react';
import { Destination } from './DestinationsSection.tsx';
import { buildWhatsAppUrl } from '../config/constants.ts';

interface DestinationDetailModalProps {
  destination: Destination | null;
  onClose: () => void;
  onOpenQuoteModal: (destName: string) => void;
}

export const DestinationDetailModal: React.FC<DestinationDetailModalProps> = ({
  destination,
  onClose,
  onOpenQuoteModal,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (destination) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [destination, onClose]);

  if (!destination) return null;

  const waReservationMsg = `Olá! Gostaria de reservar vaga na excursão para ${destination.name} com a Luzia Corrêa Turismo.`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-neutral-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-cyan-100 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header photo banner */}
        <div className="relative h-60 sm:h-72 w-full overflow-hidden bg-slate-900 shrink-0">
          <img
            src={destination.image}
            alt={destination.name}
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />

          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/20 hover:bg-white/40 text-white backdrop-blur-md transition-colors"
            aria-label="Fechar detalhes"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Title overlay */}
          <div className="absolute bottom-4 left-4 right-4 text-white">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-md text-[11px] font-extrabold uppercase tracking-wider bg-amber-400 text-neutral-950">
                {destination.categoryLabel}
              </span>
              <span className="text-xs text-neutral-300 font-medium flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-300" />
                {destination.duration}
              </span>
            </div>
            <h3 className="font-playfair text-2xl sm:text-3xl font-bold leading-tight drop-shadow">
              {destination.name}
            </h3>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Description */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Sobre a Excursão
            </h4>
            <p className="font-montserrat text-sm sm:text-base text-slate-700 leading-relaxed">
              {destination.description}
            </p>
          </div>

          {/* O que está incluso */}
          <div className="p-4 sm:p-5 rounded-2xl bg-cyan-50/70 border border-cyan-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#0E7490] mb-3 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>O que está incluso no pacote</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm text-slate-700 font-medium">
              {destination.inclusions.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Roteiro e paradas */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              Roteiro & Momentos do Passeio
            </h4>
            <div className="space-y-2.5">
              {destination.itinerary.map((step, idx) => (
                <div key={idx} className="flex items-start gap-3 text-xs sm:text-sm text-slate-700">
                  <span className="w-5 h-5 rounded-full bg-amber-400 text-neutral-950 text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span>{step}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Dicas e Recomendações */}
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200/80 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-950">
              <span className="font-bold block mb-0.5">Dica importante da Luzia:</span>
              <p>{destination.recommendation}</p>
            </div>
          </div>
        </div>

        {/* Actions Footer */}
        <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <a
            href={buildWhatsAppUrl(waReservationMsg)}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-5 rounded-xl font-extrabold text-sm text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-sm text-center"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>Reservar vaga no WhatsApp</span>
          </a>

          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenQuoteModal(destination.name);
            }}
            className="inline-flex items-center justify-center py-3 px-5 rounded-xl font-bold text-sm text-slate-800 bg-white hover:bg-slate-100 border border-slate-300 transition-colors text-center"
          >
            Solicitar orçamento completo
          </button>
        </div>
      </div>
    </div>
  );
};
