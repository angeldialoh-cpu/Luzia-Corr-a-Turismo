import React from 'react';
import { Compass, Users, ShieldCheck, HeartHandshake, ArrowDown, Sparkles, Download, FolderArchive } from 'lucide-react';
import { BRAND, buildWhatsAppUrl } from '../config/constants.ts';

// User-provided official excursion pool / park background image
const heroImageSrc = "/assets/aistudio/transferir_a6daf05e.jpeg";

interface HeroProps {
  onOpenQuoteModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenQuoteModal }) => {
  const handleScrollToExcursions = (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.querySelector('#excursoes');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="inicio" className="relative pt-24 sm:pt-28 pb-16 lg:pb-24 overflow-hidden bg-[#00B4D8]">
      {/* Decorative subtle ambient glows */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-white/20 rounded-full blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Quick Project Download Notification Bar */}
        <div className="mb-6 p-4 rounded-2xl bg-white/95 backdrop-blur-md border-2 border-amber-300 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-900">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-neutral-950 flex items-center justify-center shrink-0 font-bold shadow-sm">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <span className="font-extrabold text-sm block">
                Arquivo .ZIP do Projeto Pronto para Download
              </span>
              <span className="text-xs text-slate-600 font-medium">
                Clique abaixo para baixar para o seu computador e hospedar no Netlify ou Lovable:
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
            <a
              href="/luzia-correa-turismo-site-pronto.zip"
              download="luzia-correa-turismo-site-pronto.zip"
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-black shadow transition-all active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar para Netlify (.ZIP)</span>
            </a>
            <a
              href="/luzia-correa-turismo-codigo-fonte.zip"
              download="luzia-correa-turismo-codigo-fonte.zip"
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-800 text-white text-xs font-bold shadow transition-all active:scale-95"
            >
              <FolderArchive className="w-3.5 h-3.5 text-cyan-400" />
              <span>Código-Fonte (.ZIP)</span>
            </a>
          </div>
        </div>

        {/* Main Hero Card Container */}
        <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-cyan-200/80 bg-neutral-900">
          {/* Background Photography with enhanced sharpness and reduced scrim for maximum clarity */}
          <div className="relative h-[560px] sm:h-[620px] lg:h-[660px] w-full bg-slate-900">
            <img
              src={heroImageSrc}
              alt="Piscina e parque aquático tropical em excursão da Luzia Corrêa Turismo"
              className="w-full h-full object-cover object-center filter contrast-[1.15] brightness-[1.04] saturate-[1.1] transition-transform duration-700 hover:scale-[1.02]"
              style={{ imageRendering: 'auto' }}
              referrerPolicy="no-referrer"
            />
            {/* Lighter, localized scrim for clean contrast without muddying or blurring the photo */}
            <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/85 via-neutral-950/30 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-neutral-950/75 via-neutral-950/20 to-transparent" />
          </div>

          {/* Hero Content Overlay */}
          <div className="absolute inset-0 flex flex-col justify-end p-6 sm:p-10 lg:p-16 text-white max-w-3xl">
            {/* Small Brand Seal */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400 text-neutral-950 font-montserrat text-xs sm:text-sm font-extrabold tracking-wider uppercase mb-4 shadow-md w-fit">
              <Sparkles className="w-3.5 h-3.5 text-neutral-950 fill-neutral-950" />
              <span>SEU PRÓXIMO PASSEIO COMEÇA AQUI</span>
            </div>

            {/* Main Title: Viaje mais. Viva mais! */}
            <h1 className="font-playfair text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-tight sm:leading-none tracking-tight mb-4 drop-shadow-md">
              <span className="block text-[#E53935] drop-shadow-lg">Viaje mais.</span>
              <span className="block text-amber-300 italic font-normal sm:font-semibold">
                Viva mais!
              </span>
            </h1>

            {/* Subtitle */}
            <p className="font-montserrat text-base sm:text-lg lg:text-xl text-neutral-200 font-medium leading-relaxed mb-8 max-w-2xl drop-shadow">
              Excursões e experiências inesquecíveis pelo Rio de Janeiro, com organização, carinho e atendimento personalizado.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 sm:gap-4 mb-8">
              <button
                type="button"
                onClick={onOpenQuoteModal}
                className="inline-flex items-center justify-center px-6 sm:px-7 py-3.5 sm:py-4 rounded-xl text-sm sm:text-base font-extrabold text-neutral-950 bg-amber-400 hover:bg-amber-300 active:scale-95 shadow-lg shadow-amber-400/20 transition-all duration-200 cursor-pointer text-center"
              >
                Quero participar de uma excursão
              </button>

              <a
                href="#excursoes"
                onClick={handleScrollToExcursions}
                className="inline-flex items-center justify-center gap-2 px-6 sm:px-7 py-3.5 sm:py-4 rounded-xl text-sm sm:text-base font-bold text-white bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/30 transition-all duration-200 cursor-pointer text-center"
              >
                <span>Conheça nossas excursões</span>
                <ArrowDown className="w-4 h-4 text-amber-300" />
              </a>
            </div>

            {/* Trust Markers Bar */}
            <div className="pt-6 border-t border-white/20 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs sm:text-sm text-neutral-200">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-300 shrink-0" />
                <span className="font-medium">Cadastur Regular</span>
              </div>
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-amber-300 shrink-0" />
                <span className="font-medium">Roteiros Organizados</span>
              </div>
              <div className="flex items-center gap-2">
                <HeartHandshake className="w-4 h-4 text-amber-300 shrink-0" />
                <span className="font-medium">Atendimento de Coração</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-300 shrink-0" />
                <span className="font-medium">Grupos Acolhedores</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
