import React from 'react';
import { MapPin, Camera, Users, Sparkles, ArrowRight, CheckCircle2 } from 'lucide-react';
import { buildWhatsAppUrl } from '../config/constants.ts';

interface ServicesSectionProps {
  onSelectService: (serviceName: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  const services = [
    {
      id: '01',
      title: 'Excursões pelo Rio de Janeiro',
      description: 'Passeios organizados para conhecer lugares incríveis do Rio de Janeiro.',
      detail: 'Transporte executivo com ar-condicionado, guia credenciado e roteiro planejado nos mínimos detalhes para que você e sua família conheçam os melhores cenários da Cidade Maravilhosa com total segurança.',
      features: ['Embarque organizado', 'Transporte executivo seguro', 'Paradas fotográficas'],
      icon: MapPin,
      highlightColor: 'from-amber-400 to-amber-500',
      badge: 'Principal Especialidade',
    },
    {
      id: '02',
      title: 'Passeios turísticos',
      description: 'Experiências para aproveitar atrações, paisagens e pontos especiais.',
      detail: 'Visitas exclusivas aos cartões-postais e pontos turísticos emblemáticos: Cristo Redentor, Pão de Açúcar, Mirante Dona Marta, Floresta da Tijuca e muito mais, sem estresse com filas ou trânsito.',
      features: ['Ingressos com agilidade', 'Guiamento com histórias locais', 'Roteiro dinâmico'],
      icon: Camera,
      highlightColor: 'from-cyan-400 to-cyan-500',
      badge: 'Mais Procurado',
    },
    {
      id: '03',
      title: 'Experiências em grupo',
      description: 'Momentos especiais para viajar, conhecer lugares e compartilhar boas experiências.',
      detail: 'Viajar em grupo é fazer novos amigos, rir junto e criar memórias inesquecíveis. Ambiente acolhedor para todas as idades, com atenção dedicada a cada participante.',
      features: ['Clima familiar e acolhedor', 'Atenção especial a idosos', 'Novas amizades'],
      icon: Users,
      highlightColor: 'from-emerald-400 to-emerald-500',
      badge: 'Convivência & Alegria',
    },
    {
      id: '04',
      title: 'Viagens especiais',
      description: 'Excursões e experiências planejadas para datas e ocasiões especiais.',
      detail: 'Passeios de fim de ano, temporadas de feriados, datas comemorativas, passeios de barco e roteiros temáticos com surpresas e brindes pensados com muito carinho.',
      features: ['Roteiros comemorativos', 'Passeios temáticos e náuticos', 'Vagas limitadas'],
      icon: Sparkles,
      highlightColor: 'from-teal-400 to-teal-500',
      badge: 'Edições Limitadas',
    },
  ];

  return (
    <section id="excursoes" className="py-16 sm:py-24 bg-[#00B4D8] relative border-t border-cyan-300/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 text-[#0E7490] font-montserrat text-xs font-extrabold tracking-wider uppercase mb-3 shadow-sm">
            <span>Modalidades de Passeios</span>
          </div>

          <h2 className="font-playfair text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight mb-4 drop-shadow">
            Nossas excursões e experiências
          </h2>

          <p className="font-montserrat text-base sm:text-lg text-white/95 font-medium leading-relaxed drop-shadow-sm max-w-2xl mx-auto">
            Nada de agência genérica ou roteiros impessoais: nosso foco é realizar <strong className="font-bold text-amber-300">excursões e passeios bem cuidados</strong>, com todo o acolhimento que você merece.
          </p>
        </div>

        {/* 4 Interactive Service Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                className="group relative bg-white rounded-3xl p-6 sm:p-8 border border-cyan-100/90 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between hover:-translate-y-1"
              >
                <div>
                  {/* Top Header inside Card */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400/20 to-cyan-400/20 flex items-center justify-center text-slate-900 group-hover:bg-amber-400 transition-colors">
                        <Icon className="w-6 h-6 text-slate-900 group-hover:scale-110 transition-transform" />
                      </div>
                      <span className="font-montserrat text-xs font-bold text-slate-500 uppercase tracking-wider">
                        {service.id}
                      </span>
                    </div>

                    <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
                      {service.badge}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h3 className="font-playfair text-xl sm:text-2xl font-bold text-slate-900 mb-2 group-hover:text-cyan-800 transition-colors">
                    {service.title}
                  </h3>

                  <p className="font-montserrat text-sm sm:text-base font-semibold text-slate-700 mb-3">
                    {service.description}
                  </p>

                  <p className="font-montserrat text-xs sm:text-sm text-slate-500 leading-relaxed mb-5">
                    {service.detail}
                  </p>

                  {/* Key Highlights list */}
                  <div className="space-y-1.5 pt-3 border-t border-slate-100 mb-6">
                    {service.features.map((feat) => (
                      <div key={feat} className="flex items-center gap-2 text-xs font-medium text-slate-600">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => onSelectService(service.title)}
                    className="w-full sm:flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-xs sm:text-sm font-extrabold text-white bg-neutral-900 hover:bg-neutral-800 active:scale-98 transition-all cursor-pointer shadow-sm"
                  >
                    <span>Quero saber mais</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <a
                    href={buildWhatsAppUrl(`Olá! Gostaria de saber mais informações sobre ${service.title} da Luzia Corrêa Turismo.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center px-4 py-3 rounded-xl text-xs sm:text-sm font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-all text-center whitespace-nowrap"
                  >
                    WhatsApp Direto
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
