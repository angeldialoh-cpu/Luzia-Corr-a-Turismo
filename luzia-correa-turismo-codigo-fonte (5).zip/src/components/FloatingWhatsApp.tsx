import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { BRAND, buildWhatsAppUrl } from '../config/constants.ts';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);
  const defaultMessage = "Olá! Gostaria de saber mais sobre as excursões da Luzia Corrêa Turismo.";

  return (
    <div className="fixed bottom-5 right-5 sm:bottom-6 sm:right-6 z-40 flex flex-col items-end pointer-events-none">
      {/* Tooltip bubble */}
      {showTooltip && (
        <div className="mb-3 max-w-xs bg-white rounded-2xl p-3 shadow-2xl border border-cyan-100 text-slate-800 text-xs font-medium pointer-events-auto flex items-start gap-2.5 animate-in slide-in-from-bottom-2 duration-300">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0 mt-1" />
          <div className="flex-1">
            <span className="font-bold text-slate-900 block font-montserrat">
              Luzia Corrêa Turismo
            </span>
            <span className="text-slate-600">
              Dúvidas sobre passeios ou reservas? Fale com a gente no WhatsApp!
            </span>
          </div>
          <button
            type="button"
            onClick={() => setShowTooltip(false)}
            className="text-slate-400 hover:text-slate-600 p-0.5"
            aria-label="Fechar aviso"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Button */}
      <a
        href={buildWhatsAppUrl(defaultMessage)}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Conversar com Luzia Corrêa Turismo pelo WhatsApp"
        className="pointer-events-auto relative group flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white shadow-xl shadow-emerald-600/30 transition-all duration-200 hover:shadow-2xl"
      >
        {/* Pulsing ring indicator */}
        <span className="absolute inset-0 rounded-full bg-emerald-400 opacity-75 animate-ping -z-10 group-hover:opacity-100" />

        {/* WhatsApp Icon */}
        <MessageCircle className="w-7 h-7 sm:w-8 sm:h-8 fill-white text-emerald-500" />
      </a>
    </div>
  );
};
