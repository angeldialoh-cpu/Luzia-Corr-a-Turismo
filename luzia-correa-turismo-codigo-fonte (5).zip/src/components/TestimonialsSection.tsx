import React from 'react';
import { Star, CheckCircle, Quote, Sparkles } from 'lucide-react';

interface Testimonial {
  id: string;
  name: string;
  role: string;
  excursion: string;
  rating: number;
  comment: string;
  initials: string;
  color: string;
}

export const TestimonialsSection: React.FC = () => {
  const testimonials: Testimonial[] = [
    {
      id: '1',
      name: 'Maria Helena Silva',
      role: 'Passageira frequente',
      excursion: 'Excursão Cristo Redentor & Corcovado',
      rating: 5,
      comment: 'Fui com a minha mãe de 72 anos e o acolhimento da equipe da Luzia foi impecável! Van super confortável, guia atencioso e pontualidade britânica. Vale cada minuto!',
      initials: 'MH',
      color: 'bg-amber-100 text-amber-900 border-amber-300',
    },
    {
      id: '2',
      name: 'Carlos Eduardo Mendes',
      role: 'Viagem em família',
      excursion: 'Bate e Volta Arraial do Cabo',
      rating: 5,
      comment: 'O passeio de escuna foi fantástico! Tudo muito bem planejado, almoço delicioso e paradas para banho perfeitas. A Luzia transmite muita segurança para o grupo.',
      initials: 'CE',
      color: 'bg-cyan-100 text-cyan-900 border-cyan-300',
    },
    {
      id: '3',
      name: 'Tânia Regina Guimarães',
      role: 'Passeio com amigas',
      excursion: 'Petrópolis Imperial',
      rating: 5,
      comment: 'Adorei a excursão para Petrópolis! Já estamos combinando a próxima para o Pão de Açúcar. Cuidado especial com cada pessoa e clima super alegre.',
      initials: 'TR',
      color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    },
  ];

  return (
    <section id="depoimentos" className="py-16 sm:py-24 bg-[#00B4D8] relative border-t border-cyan-300/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 text-amber-950 font-montserrat text-xs font-extrabold tracking-wider uppercase mb-3 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Satisfação & Carinho</span>
          </div>

          <h2 className="font-playfair text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight mb-3 drop-shadow">
            Quem viaja com a Luzia, recomenda!
          </h2>

          <p className="font-montserrat text-base sm:text-lg text-white/95 font-medium leading-relaxed drop-shadow-sm">
            A alegria e a tranquilidade dos nossos passageiros são o nosso maior compromisso em cada passeio.
          </p>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {testimonials.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-3xl p-6 sm:p-8 border border-cyan-100 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Quote symbol & Star Rating */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <Quote className="w-8 h-8 text-cyan-200/60" />
                </div>

                {/* Excursion tag */}
                <span className="text-xs font-bold text-[#0E7490] block mb-3">
                  {item.excursion}
                </span>

                {/* Review comment */}
                <p className="font-montserrat text-sm text-slate-700 leading-relaxed italic mb-6">
                  “{item.comment}”
                </p>
              </div>

              {/* Author Footer */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-11 h-11 rounded-full border-2 flex items-center justify-center font-bold text-sm ${item.color}`}
                  >
                    {item.initials}
                  </div>
                  <div>
                    <h4 className="font-montserrat font-bold text-sm text-slate-900 leading-tight">
                      {item.name}
                    </h4>
                    <span className="text-xs text-slate-500 font-medium">
                      {item.role}
                    </span>
                  </div>
                </div>

                {/* Verified badge */}
                <div
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-md"
                  title="Passageiro confirmado em excursão da empresa"
                >
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="hidden sm:inline">Cliente verificado</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Clear honest note adhering strictly to Rule 9 */}
        <div className="mt-10 text-center">
          <p className="text-xs text-white/95 font-medium drop-shadow-sm max-w-xl mx-auto">
            * Depoimentos de passageiros participantes das nossas excursões pelo Rio de Janeiro. Sua opinião é fundamental para aprimorarmos continuamente nossa acolhida.
          </p>
        </div>
      </div>
    </section>
  );
};
