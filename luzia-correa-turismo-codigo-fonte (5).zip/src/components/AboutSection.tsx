import React, { useState } from 'react';
import { UserCheck, CalendarCheck, Sparkles, Headset, MessageCircle, Heart, ZoomIn, X } from 'lucide-react';
import { buildWhatsAppUrl } from '../config/constants.ts';

// Official Quem Somos flyer image provided by client
const quemSomosPosterSrc = "/assets/aistudio/81e2ad5f-c8f0-47d0-9ec3-c6ee0cb28e8d_878ff27c.jpeg";

interface AboutSectionProps {
  onOpenQuoteModal: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onOpenQuoteModal }) => {
  const [isZoomOpen, setIsZoomOpen] = useState(false);

  const benefits = [
    {
      title: 'Atendimento personalizado',
      description: 'Cuidado humano e carinho em cada contato, tirando todas as suas dúvidas com paciência e dedicação.',
      icon: UserCheck,
    },
    {
      title: 'Organização e planejamento',
      description: 'Pontualidade, roteiros equilibrados e paradas selecionadas para que seu passeio seja leve e proveitoso.',
      icon: CalendarCheck,
    },
    {
      title: 'Praticidade para o cliente',
      description: 'Pontos de encontro convenientes, transporte executivo seguro e tudo pronto para você só relaxar.',
      icon: Sparkles,
    },
    {
      title: 'Suporte próximo',
      description: 'Equipe sempre presente antes, durante e após o passeio para garantir a sua tranquilidade total.',
      icon: Headset,
    },
  ];

  return (
    <section id="quem-somos" className="py-16 sm:py-24 bg-[#00B4D8] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Left Column: Official "Quem Somos" Poster provided by client */}
          <div className="lg:col-span-5 order-2 lg:order-1">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Flyer Container with interactive zoom */}
              <div
                onClick={() => setIsZoomOpen(true)}
                className="group relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-white cursor-pointer transition-all duration-300 hover:shadow-cyan-950/20 hover:-translate-y-1"
                title="Clique para ampliar a imagem oficial Quem Somos"
              >
                <img
                  src={quemSomosPosterSrc}
                  alt="Luzia Corrêa Turismo - Quem Somos Oficial e Grupo de Passageiros"
                  className="w-full h-auto object-cover object-center group-hover:scale-[1.02] transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />

                {/* Hover overlay hint */}
                <div className="absolute inset-0 bg-neutral-950/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/95 text-neutral-950 font-montserrat text-xs font-bold shadow-lg">
                    <ZoomIn className="w-4 h-4 text-amber-500" />
                    <span>Clique para ampliar</span>
                  </span>
                </div>
              </div>

              {/* Floating trust badge */}
              <div className="absolute -bottom-4 -right-2 sm:-right-4 bg-white/95 backdrop-blur-md rounded-2xl p-3.5 shadow-xl border border-white flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-amber-400 flex items-center justify-center text-neutral-950 font-bold shadow-sm shrink-0">
                  <Heart className="w-5 h-5 fill-neutral-950" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">Turismo com Afeto</div>
                  <div className="text-[11px] text-slate-500 font-medium">Sua próxima aventura começa aqui!</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Institutional Text & Benefits */}
          <div className="lg:col-span-7 order-1 lg:order-2">
            {/* Tagline */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 text-[#0E7490] font-montserrat text-xs font-extrabold tracking-wider uppercase mb-3 shadow-sm">
              <span>Quem Somos</span>
            </div>

            {/* Main Title */}
            <h2 className="font-playfair text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight mb-4 drop-shadow">
              Viajar é criar histórias.
            </h2>

            {/* Slogan & Core message from official material */}
            <p className="font-montserrat text-base sm:text-lg text-[#082F49] leading-relaxed font-semibold mb-4 bg-white/80 backdrop-blur-sm p-4 rounded-2xl border border-white/60 shadow-sm">
              A <strong className="font-bold text-neutral-950">Luzia Corrêa Turismo</strong> organiza passeios em grupo para você conhecer, curtir e viver momentos incríveis, com todo o <strong className="font-bold text-red-600">conforto e segurança</strong>.
            </p>

            <p className="font-montserrat text-sm sm:text-base text-[#082F49] font-medium leading-relaxed mb-8 bg-white/60 backdrop-blur-sm p-3.5 rounded-2xl border border-white/40">
              Exploramos destinos no Rio de Janeiro e diversas opções de passeios para todos os gostos (passeios no Rio, parques aquáticos, praias e ilhas, sítios e hotéis-fazenda), sempre com <strong className="font-bold text-neutral-950">muita boa companhia</strong> e um atendimento próximo em cada viagem.
            </p>

            {/* 4 Benefits with check icons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5 mb-8">
              {benefits.map((benefit) => {
                const IconComponent = benefit.icon;
                return (
                  <div
                    key={benefit.title}
                    className="p-4 sm:p-5 rounded-2xl bg-white border border-cyan-100 shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start gap-3.5">
                      <div className="w-9 h-9 rounded-xl bg-amber-400/20 text-neutral-950 flex items-center justify-center shrink-0">
                        <IconComponent className="w-5 h-5 text-amber-700" />
                      </div>
                      <div>
                        <h3 className="font-montserrat font-bold text-sm sm:text-base text-slate-900 mb-1">
                          ✓ {benefit.title}
                        </h3>
                        <p className="text-xs sm:text-sm text-slate-600 leading-snug">
                          {benefit.description}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Fale Conosco Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <a
                href={buildWhatsAppUrl("Olá! Gostaria de falar com a Luzia Corrêa Turismo e conhecer as próximas excursões.")}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-6 sm:px-7 py-3.5 rounded-xl text-sm sm:text-base font-extrabold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 shadow-md shadow-emerald-600/20 transition-all cursor-pointer text-center"
              >
                <MessageCircle className="w-5 h-5 fill-white" />
                <span>Fale conosco no WhatsApp</span>
              </a>

              <button
                type="button"
                onClick={onOpenQuoteModal}
                className="inline-flex items-center justify-center px-6 py-3.5 rounded-xl text-sm sm:text-base font-bold text-slate-800 bg-white hover:bg-slate-50 border border-slate-200 shadow-sm transition-all cursor-pointer text-center"
              >
                Solicitar orçamento
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox / Zoom Modal for the full flyer */}
      {isZoomOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/85 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setIsZoomOpen(false)}
        >
          <div
            className="relative max-w-2xl w-full max-h-[90vh] bg-white rounded-3xl overflow-hidden shadow-2xl p-2 flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setIsZoomOpen(false)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-neutral-900/80 text-white hover:bg-neutral-950 transition-colors"
              aria-label="Fechar"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="overflow-y-auto max-h-[85vh] rounded-2xl">
              <img
                src={quemSomosPosterSrc}
                alt="Luzia Corrêa Turismo - Quem Somos Oficial"
                className="w-full h-auto object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
