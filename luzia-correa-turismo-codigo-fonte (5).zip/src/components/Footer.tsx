import React from 'react';
import { Logo } from './Logo.tsx';
import { Phone, Mail, MapPin, Instagram, MessageCircle, Heart, Download, FolderArchive } from 'lucide-react';
import { BRAND, buildWhatsAppUrl } from '../config/constants.ts';

interface FooterProps {
  onOpenQuoteModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenQuoteModal }) => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="contato" className="bg-neutral-950 text-white border-t border-cyan-900/40 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-neutral-800">
          {/* Col 1: Brand presentation & Slogan (4 cols) */}
          <div className="lg:col-span-5">
            <div className="mb-4">
              <Logo variant="default" showSlogan={true} />
            </div>

            <p className="font-playfair text-amber-400 italic text-lg font-semibold mb-3">
              “{BRAND.slogan}”
            </p>

            <p className="font-montserrat text-sm text-neutral-400 leading-relaxed max-w-sm mb-6">
              {BRAND.description}
            </p>

            {/* Social Links */}
            <div className="flex items-center gap-3">
              <a
                href={BRAND.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-amber-400 hover:text-neutral-950 text-neutral-300 text-xs font-semibold transition-colors"
                aria-label="Instagram da Luzia Corrêa Turismo"
              >
                <Instagram className="w-4 h-4 text-pink-400" />
                <span>@luzia_correaturismo</span>
              </a>
              <a
                href={buildWhatsAppUrl("Olá! Gostaria de conversar com a Luzia Corrêa Turismo.")}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center transition-colors shadow-sm"
                aria-label="Conversar no WhatsApp"
              >
                <MessageCircle className="w-5 h-5 fill-white" />
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links (3 cols) */}
          <div className="lg:col-span-3">
            <h4 className="font-montserrat text-xs font-bold uppercase tracking-wider text-amber-400 mb-4">
              Navegação Rápida
            </h4>
            <ul className="space-y-2.5 text-sm font-medium text-neutral-300">
              <li>
                <a
                  href="#inicio"
                  onClick={(e) => handleNavClick(e, '#inicio')}
                  className="hover:text-amber-400 transition-colors"
                >
                  Início
                </a>
              </li>
              <li>
                <a
                  href="#quem-somos"
                  onClick={(e) => handleNavClick(e, '#quem-somos')}
                  className="hover:text-amber-400 transition-colors"
                >
                  Quem Somos
                </a>
              </li>
              <li>
                <a
                  href="#excursoes"
                  onClick={(e) => handleNavClick(e, '#excursoes')}
                  className="hover:text-amber-400 transition-colors"
                >
                  Excursões e Passeios
                </a>
              </li>
              <li>
                <a
                  href="#destinos"
                  onClick={(e) => handleNavClick(e, '#destinos')}
                  className="hover:text-amber-400 transition-colors"
                >
                  Destinos no Rio
                </a>
              </li>
              <li>
                <a
                  href="#depoimentos"
                  onClick={(e) => handleNavClick(e, '#depoimentos')}
                  className="hover:text-amber-400 transition-colors"
                >
                  Depoimentos
                </a>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenQuoteModal}
                  className="text-amber-400 hover:underline font-bold text-left cursor-pointer"
                >
                  Solicitar orçamento
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact details & Cadastur (4 cols) */}
          <div className="lg:col-span-4">
            <h4 className="font-montserrat text-xs font-bold uppercase tracking-wider text-amber-400 mb-4">
              Atendimento & Contato
            </h4>
            <div className="space-y-3 text-sm text-neutral-300 mb-6">
              <a
                href={buildWhatsAppUrl("Olá! Gostaria de informações sobre as excursões.")}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-emerald-500/50 transition-colors"
              >
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <MessageCircle className="w-4 h-4 fill-emerald-400" />
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-neutral-400 block font-bold">
                    WhatsApp de Reservas
                  </span>
                  <span className="font-bold text-white text-sm">
                    {BRAND.whatsappDisplay}
                  </span>
                </div>
              </a>

              <div className="flex items-center gap-3 text-neutral-300">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{BRAND.location}</span>
              </div>

              <a
                href={`mailto:${BRAND.email}`}
                className="flex items-center gap-3 text-neutral-300 hover:text-amber-400 transition-colors"
              >
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{BRAND.email}</span>
              </a>
            </div>

            <div className="p-3 rounded-xl bg-neutral-900/70 border border-neutral-800 text-xs text-neutral-400">
              <span className="font-bold text-neutral-200 block mb-0.5">Turismo Regularizado:</span>
              <span>{BRAND.cadastur} • Agência de Turismo Receptivo e Excursões</span>
            </div>
          </div>
        </div>

        {/* Download Project Archives for Netlify & Lovable */}
        <div className="pt-8 pb-4 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-center sm:text-left">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
              Download do Projeto (Netlify / Lovable)
            </span>
            <p className="text-xs text-neutral-400">
              Arquivos .ZIP completos prontos para publicação ou edição.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            <a
              href="/luzia-correa-turismo-site-pronto.zip"
              download="luzia-correa-turismo-site-pronto.zip"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 text-xs font-extrabold transition-all shadow-sm"
              title="Baixar arquivos compilados para arrastar no Netlify Drop"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar para Netlify (.ZIP)</span>
            </a>
            <a
              href="/luzia-correa-turismo-codigo-fonte.zip"
              download="luzia-correa-turismo-codigo-fonte.zip"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold transition-all border border-neutral-700"
              title="Baixar código-fonte completo para Lovable ou GitHub"
            >
              <FolderArchive className="w-3.5 h-3.5 text-cyan-400" />
              <span>Código-Fonte Completo (.ZIP)</span>
            </a>
          </div>
        </div>

        {/* Bottom Bar: Copyright exact as specified */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500 font-medium">
          <p>© 2026 Luzia Corrêa Turismo. Todos os direitos reservados.</p>
          <p className="flex items-center gap-1.5 text-neutral-400">
            <span>Feito com carinho para quem ama o Rio de Janeiro</span>
            <Heart className="w-3.5 h-3.5 text-amber-400 fill-amber-400 inline" />
          </p>
        </div>
      </div>
    </footer>
  );
};
