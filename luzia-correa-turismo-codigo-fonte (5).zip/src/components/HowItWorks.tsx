import React from 'react';
import { MessageSquareText, FileText, CheckCircle, Luggage, ArrowRight } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      step: '01',
      title: 'Conte qual passeio você deseja',
      description: 'Escolha a excursão ou experiência que mais combina com você.',
      icon: MessageSquareText,
    },
    {
      step: '02',
      title: 'Receba as informações',
      description: 'Nossa equipe apresenta detalhes, valores e disponibilidade.',
      icon: FileText,
    },
    {
      step: '03',
      title: 'Faça sua reserva',
      description: 'Confirme sua participação de forma simples e prática.',
      icon: CheckCircle,
    },
    {
      step: '04',
      title: 'Prepare-se para viajar!',
      description: 'Agora é só preparar as malas e aproveitar a experiência.',
      icon: Luggage,
    },
  ];

  return (
    <section className="py-16 sm:py-24 bg-[#00B4D8] relative overflow-hidden border-t border-cyan-300/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 text-[#0E7490] font-montserrat text-xs font-extrabold tracking-wider uppercase mb-3 shadow-sm">
            <span>Passo a Passo Simples</span>
          </div>

          <h2 className="font-playfair text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight mb-3 drop-shadow">
            Como funciona?
          </h2>

          <p className="font-montserrat text-base sm:text-lg text-white/95 font-medium leading-relaxed drop-shadow-sm">
            Sem burocracia: veja como é fácil e seguro embarcar com a Luzia Corrêa Turismo.
          </p>
        </div>

        {/* 4 Steps Container */}
        <div className="relative">
          {/* Connector line for desktop */}
          <div className="hidden lg:block absolute top-1/2 left-12 right-12 h-1 bg-gradient-to-r from-amber-400 via-cyan-400 to-emerald-400 -translate-y-8 -z-0" />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 relative z-10">
            {steps.map((item, index) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.step}
                  className="bg-white rounded-3xl p-6 sm:p-7 border border-cyan-100 shadow-sm hover:shadow-lg transition-all flex flex-col items-center text-center relative group"
                >
                  {/* Step Number Badge */}
                  <div className="w-14 h-14 rounded-2xl bg-amber-400 text-neutral-950 font-montserrat font-extrabold text-lg flex items-center justify-center shadow-md mb-5 group-hover:scale-110 transition-transform">
                    {item.step}
                  </div>

                  {/* Icon */}
                  <div className="w-10 h-10 rounded-full bg-cyan-50 text-[#0E7490] flex items-center justify-center mb-4">
                    <Icon className="w-5 h-5" />
                  </div>

                  {/* Title */}
                  <h3 className="font-playfair text-lg sm:text-xl font-bold text-slate-900 mb-2 leading-snug">
                    {item.title}
                  </h3>

                  {/* Description */}
                  <p className="font-montserrat text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {item.description}
                  </p>

                  {/* Step arrow indicator on mobile */}
                  {index < steps.length - 1 && (
                    <div className="lg:hidden mt-4 text-cyan-400">
                      <ArrowRight className="w-4 h-4 rotate-90 sm:rotate-0 mx-auto" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
