import React from 'react';
import { MessageCircle, Calendar, Sparkles, PhoneCall } from 'lucide-react';
import { BRAND, buildWhatsAppUrl } from '../config/constants.ts';

interface FinalCtaSectionProps {
  onOpenQuoteModal: () => void;
}

export const FinalCtaSection: React.FC<FinalCtaSectionProps> = ({ onOpenQuoteModal }) => {
  const defaultWhatsAppMsg = "Olá! Gostaria de saber mais sobre as excursões da Luzia Corrêa Turismo e reservar minha vaga.";

  return (
    <section className="py-16 sm:py-24 bg-[#00B4D8] relative border-t border-cyan-300/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-neutral-900 via-neutral-950 to-[#082f49] text-white p-8 sm:p-12 lg:p-16 shadow-2xl border border-cyan-800/40">
          {/* Subtle tropical atmospheric highlights */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-3xl mx-auto text-center">
            {/* Seal / Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400 text-neutral-950 font-montserrat text-xs font-extrabold tracking-wider uppercase mb-5 shadow-sm">
              <Sparkles className="w-3.5 h-3.5 fill-neutral-950" />
              <span>VIAJE MAIS. VIVA MAIS!</span>
            </div>

            {/* Main Title */}
            <h2 className="font-playfair text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight mb-4 leading-tight">
              Pronto para viver sua próxima experiência?
            </h2>

            {/* Subtext */}
            <p className="font-montserrat text-base sm:text-lg text-neutral-300 font-normal leading-relaxed mb-8 max-w-2xl mx-auto">
              Escolha sua excursão e fale com a <strong className="text-white font-semibold">Luzia Corrêa Turismo</strong>. Cuidamos de cada detalhe para que você viva momentos inesquecíveis pelo Rio de Janeiro.
            </p>

            {/* Conversion Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-4 mb-8">
              <a
                href={buildWhatsAppUrl(defaultWhatsAppMsg)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl text-base font-extrabold text-neutral-950 bg-amber-400 hover:bg-amber-300 active:scale-95 shadow-lg shadow-amber-400/25 transition-all cursor-pointer text-center"
              >
                <MessageCircle className="w-5 h-5 fill-neutral-950" />
                <span>Quero participar de uma excursão</span>
              </a>

              <button
                type="button"
                onClick={onOpenQuoteModal}
                className="inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl text-base font-bold text-white bg-white/10 hover:bg-white/20 border border-white/20 transition-all cursor-pointer text-center"
              >
                <Calendar className="w-5 h-5 text-amber-300" />
                <span>Solicitar orçamento detalhado</span>
              </button>
            </div>

            {/* Direct contact caption */}
            <div className="flex flex-wrap items-center justify-center gap-4 text-xs sm:text-sm text-neutral-400 font-medium">
              <span className="flex items-center gap-1.5">
                <PhoneCall className="w-4 h-4 text-amber-300" />
                <span>Atendimento humano no WhatsApp: <strong className="text-white">{BRAND.whatsappDisplay}</strong></span>
              </span>
              <span className="hidden sm:inline">•</span>
              <span>{BRAND.cadastur}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
