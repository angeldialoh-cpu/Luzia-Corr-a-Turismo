import React, { useState, useEffect } from 'react';
import { Logo } from './Logo.tsx';
import { Menu, X, MessageCircle, Download } from 'lucide-react';
import { BRAND, buildWhatsAppUrl } from '../config/constants.ts';

interface HeaderProps {
  onOpenQuoteModal: (presetDestination?: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenQuoteModal }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Início', href: '#inicio' },
    { name: 'Quem Somos', href: '#quem-somos' },
    { name: 'Excursões', href: '#excursoes' },
    { name: 'Destinos', href: '#destinos' },
    { name: 'Depoimentos', href: '#depoimentos' },
    { name: 'Contato', href: '#contato' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 bg-[#FFBF00] transition-all duration-200 border-b border-amber-500/40 ${
        scrolled ? 'shadow-lg py-2.5 sm:py-3' : 'shadow-md py-3.5 sm:py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4">
          {/* Zone 1: Logo Oficial com a imagem enviada e nome em vermelho */}
          <a
            href="#inicio"
            onClick={(e) => handleNavClick(e, '#inicio')}
            className="flex items-center focus:outline-none focus-visible:ring-2 focus-visible:ring-black rounded-lg"
            aria-label="Luzia Corrêa Turismo - Início"
          >
            <Logo variant="header" showSlogan={false} size="md" />
          </a>

          {/* Zone 2: Navigation Links (Preto, em negrito) */}
          <nav
            aria-label="Navegação principal"
            className="hidden lg:flex items-center gap-6 xl:gap-8 text-neutral-950 font-bold text-sm tracking-wide"
          >
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="whitespace-nowrap transition-colors hover:text-neutral-800 relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-neutral-950 hover:after:w-full after:transition-all after:duration-200"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Zone 3: Botão Baixar .ZIP + Botão de destaque "Solicitar orçamento" + Mobile Toggle */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <a
              href="/luzia-correa-turismo-site-pronto.zip"
              download="luzia-correa-turismo-site-pronto.zip"
              className="inline-flex items-center gap-1.5 px-3 sm:px-4 py-2 sm:py-2.5 text-xs sm:text-sm font-extrabold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 transition-all rounded-xl shadow-md whitespace-nowrap cursor-pointer"
              title="Baixar arquivo .ZIP para Netlify"
            >
              <Download className="w-4 h-4" />
              <span>Baixar .ZIP</span>
            </a>

            <button
              onClick={() => onOpenQuoteModal()}
              type="button"
              className="hidden sm:inline-flex items-center justify-center px-4 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm font-extrabold text-white bg-[#0284C7] hover:bg-[#0369A1] active:bg-[#075985] active:scale-95 transition-all duration-150 rounded-xl shadow-md shadow-sky-900/15 whitespace-nowrap cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-sky-600"
            >
              Solicitar orçamento
            </button>

            {/* Mobile menu button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-neutral-950 hover:bg-amber-400 focus:outline-none focus:ring-2 focus:ring-neutral-950 transition-colors"
              aria-expanded={mobileMenuOpen}
              aria-label={mobileMenuOpen ? 'Fechar menu de navegação' : 'Abrir menu de navegação'}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FFBF00] border-t border-amber-500/50 px-4 pt-3 pb-6 shadow-xl animate-in fade-in duration-150">
          <nav className="flex flex-col space-y-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="px-3 py-2 text-base font-bold text-neutral-950 hover:bg-amber-300 rounded-md transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>
          <div className="pt-4 mt-2 border-t border-amber-500/40 flex flex-col gap-2.5">
            <a
              href="/luzia-correa-turismo-site-pronto.zip"
              download="luzia-correa-turismo-site-pronto.zip"
              className="w-full py-2.5 px-4 text-center text-xs font-extrabold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl flex items-center justify-center gap-2 shadow transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Baixar Arquivo .ZIP do Projeto</span>
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenQuoteModal();
              }}
              type="button"
              className="w-full py-3 px-4 text-center text-sm font-extrabold text-white bg-[#0284C7] hover:bg-[#0369A1] rounded-xl shadow cursor-pointer transition-colors"
            >
              Solicitar orçamento
            </button>
            <a
              href={buildWhatsAppUrl("Olá! Gostaria de saber mais sobre as excursões da Luzia Corrêa Turismo.")}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-4 text-center text-xs font-bold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              <MessageCircle className="w-4 h-4 fill-emerald-950" />
              WhatsApp Direto: {BRAND.whatsappDisplay}
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
