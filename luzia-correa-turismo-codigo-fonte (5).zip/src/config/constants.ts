/**
 * Official Brand and Contact Configuration for Luzia Corrêa Turismo
 */
export const BRAND = {
  name: "Luzia Corrêa Turismo",
  shortName: "Luzia Corrêa",
  slogan: "Viaje mais. Viva mais!",
  tagline: "Excursões e experiências inesquecíveis pelo Rio de Janeiro",
  description: "A Luzia Corrêa Turismo nasceu para transformar passeios em momentos especiais. Trabalhamos com excursões e experiências pelo Rio de Janeiro, oferecendo organização, praticidade e um atendimento próximo em cada viagem.",
  
  // WhatsApp Contact Configuration from official flyer
  whatsappNumber: "5521985396446",
  whatsappDisplay: "(21) 98539-6446",
  email: "luziadocoutocorreia@gmail.com",
  instagramHandle: "@luzia_correaturismo",
  location: "Rio de Janeiro - RJ",
  cadastur: "CADASTUR 19.229619.68-7",
  
  social: {
    instagram: "https://instagram.com/luzia_correaturismo",
  }
};

/**
 * Helper to build custom WhatsApp direct URLs
 */
export function buildWhatsAppUrl(message: string, phone: string = BRAND.whatsappNumber): string {
  const cleanPhone = phone.replace(/\D/g, "");
  const encodedText = encodeURIComponent(message.trim());
  return `https://wa.me/${cleanPhone}?text=${encodedText}`;
}
