/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Download } from 'lucide-react';
import { Header } from './components/Header.tsx';
import { Hero } from './components/Hero.tsx';
import { AboutSection } from './components/AboutSection.tsx';
import { ServicesSection } from './components/ServicesSection.tsx';
import { DestinationsSection, Destination } from './components/DestinationsSection.tsx';
import { HowItWorks } from './components/HowItWorks.tsx';
import { TestimonialsSection } from './components/TestimonialsSection.tsx';
import { FinalCtaSection } from './components/FinalCtaSection.tsx';
import { FloatingWhatsApp } from './components/FloatingWhatsApp.tsx';
import { QuoteModal } from './components/QuoteModal.tsx';
import { DestinationDetailModal } from './components/DestinationDetailModal.tsx';
import { DownloadModal } from './components/DownloadModal.tsx';
import { Footer } from './components/Footer.tsx';

export default function App() {
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [quotePresetDestination, setQuotePresetDestination] = useState<string>('');
  const [selectedDestinationDetail, setSelectedDestinationDetail] = useState<Destination | null>(null);

  const handleOpenQuoteModal = (destinationName?: string) => {
    setQuotePresetDestination(destinationName || '');
    setIsQuoteModalOpen(true);
  };

  const handleCloseQuoteModal = () => {
    setIsQuoteModalOpen(false);
  };

  const handleOpenDestinationDetails = (destination: Destination) => {
    setSelectedDestinationDetail(destination);
  };

  const handleCloseDestinationDetails = () => {
    setSelectedDestinationDetail(null);
  };

  const handleSelectService = (serviceName: string) => {
    handleOpenQuoteModal(serviceName);
  };

  return (
    <div className="min-h-screen bg-[#00B4D8] text-slate-800 font-sans flex flex-col selection:bg-amber-400 selection:text-neutral-950">
      {/* Cabeçalho fixo no topo: Amarelo com textos em preto, negrito */}
      <Header onOpenQuoteModal={handleOpenQuoteModal} />

      {/* Conteúdo Principal */}
      <main className="flex-1">
        {/* Seção Hero */}
        <Hero onOpenQuoteModal={() => handleOpenQuoteModal()} />

        {/* Seção Quem Somos */}
        <AboutSection onOpenQuoteModal={() => handleOpenQuoteModal()} />

        {/* Seção Excursões e Serviços */}
        <ServicesSection onSelectService={handleSelectService} />

        {/* Seção Destinos e Passeios com prioridade ao Rio de Janeiro */}
        <DestinationsSection
          onOpenDetails={handleOpenDestinationDetails}
          onOpenQuoteModal={handleOpenQuoteModal}
        />

        {/* Seção Como Funciona (4 passos) */}
        <HowItWorks />

        {/* Seção de Depoimentos */}
        <TestimonialsSection />

        {/* Seção CTA Final */}
        <FinalCtaSection onOpenQuoteModal={() => handleOpenQuoteModal()} />
      </main>

      {/* Rodapé completo */}
      <Footer onOpenQuoteModal={() => handleOpenQuoteModal()} />

      {/* Botão Flutuante do WhatsApp permanente */}
      <FloatingWhatsApp />

      {/* Botão Flutuante de Download do Projeto */}
      <div className="fixed bottom-6 left-6 z-40">
        <button
          type="button"
          onClick={() => setIsDownloadModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-3 rounded-full bg-neutral-950 text-white font-montserrat text-xs sm:text-sm font-extrabold shadow-2xl border-2 border-amber-400 hover:bg-neutral-900 hover:scale-105 active:scale-95 transition-all cursor-pointer backdrop-blur-md"
          title="Baixar arquivos do projeto para Netlify ou Lovable"
        >
          <Download className="w-4 h-4 text-amber-400" />
          <span>Baixar Projeto (.ZIP)</span>
        </button>
      </div>

      {/* Modal / Formulário de Orçamento com montagem para WhatsApp */}
      <QuoteModal
        isOpen={isQuoteModalOpen}
        onClose={handleCloseQuoteModal}
        presetDestination={quotePresetDestination}
      />

      {/* Modal de Detalhes do Destino / Excursão */}
      <DestinationDetailModal
        destination={selectedDestinationDetail}
        onClose={handleCloseDestinationDetails}
        onOpenQuoteModal={handleOpenQuoteModal}
      />

      {/* Modal de Download dos Arquivos ZIP */}
      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />
    </div>
  );
}
